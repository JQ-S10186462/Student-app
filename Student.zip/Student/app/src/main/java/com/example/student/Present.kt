package com.example.student

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.widget.Toast
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_present.*

class Present : AppCompatActivity() {

    var script = "https://script.google.com/macros/s/AKfycbzjmCkpW5LuFOvdPbdVScr2IPNFTFQ3ZjubgIL7Jpv7xdKhvFnY/exec?"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_present)

        val sharedPreference: SharedPreference = SharedPreference(this)

        Status.setOnClickListener {
            startActivity(Intent(this, Unavailable::class.java))
        }


        Avaliable.setOnClickListener {
            val ID = sharedPreference.getValueString("ID")
            val NPISID = sharedPreference.getValueString("Supervisor")

            val queue = Volley.newRequestQueue(this)
            var input = ""
            input += script + "NPISID=" + NPISID + "&Course=*&StudentID=s" + ID + "&Present=1"

            val stringRequest = object : StringRequest(Request.Method.GET, input,
                Response.Listener<String> {
                    Toast.makeText(applicationContext, "Attendance Submitted", Toast.LENGTH_SHORT)
                        .show()
                },
                Response.ErrorListener {
                    Toast.makeText(applicationContext, "Please try again", Toast.LENGTH_SHORT)
                        .show()
                }
            ) {}

            stringRequest.setRetryPolicy(
                DefaultRetryPolicy(
                    0,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                )
            )
            queue.add(stringRequest)




        }

        button.setOnClickListener{
            val Postal = sharedPreference.getValueString("Postal")
            val textView = findViewById<TextView>(R.id.textView3)



            val queue = Volley.newRequestQueue(this)
            val script = "https://developers.onemap.sg/commonapi/search?searchVal="
            var url = ""

            url +=  script + Postal + "&returnGeom=Y&getAddrDetails=Y&pageNum=1"


            val stringRequest = object : StringRequest(Request.Method.POST, url,
                Response.Listener<String> { response ->
                    textView.text = "Response is: ${response.substring(0, 500)}"
                },
                Response.ErrorListener { textView.text = "Never" })
            {}
            stringRequest.setRetryPolicy(
                DefaultRetryPolicy(
                    0,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT))
            queue.add(stringRequest)
        }
    }
    }

